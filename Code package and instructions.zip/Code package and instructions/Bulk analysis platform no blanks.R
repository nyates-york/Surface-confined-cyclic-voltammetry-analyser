source(paste("Background codes","\\","Function libary.R",sep=""))
Referencepot = -0.2482
Temperature= 298
ElectrodeArea=1
Coverageguess=200


ListofExtractedAnodic=list()
ListofExtractedCathodic=list()

ListofAnodicReconstruct=list()
ListofCathodicReconstruct=list()

ListofAnodic1=list()
ListofAnodic2=list()
ListofCathodic1=list()
ListofCathodic2=list()
ListofFittedparameters=list()

Filenames=c()

Scanrates=c(113,83,63,52,213,431,1111,2133,4217,815,313,153,3333,153,1515,613,153,213,42,33,18,12,6,4217,6013,8613,11111,16161,18313,28313,38313,113,4217,6013,8613,11111,16161,18313,28313,38313,48313)
Expno=seq.int(1,length(Scanrates),1)

for(i in 1:length(Scanrates)){
  k=Expno[i]
  file=paste(k, " LPMO CV after sine ",Scanrates[i],"_4", sep="")
  Filenames=c(Filenames, file)
  }

for(i in 1:length(Filenames)){
  Filenames[i]=paste("LPMO","\\",Filenames[i], sep="")
  
}




#"LPMO light red 83_4", "LPMO light red 63_4","LPMO light red 52_4","LPMO light red 43_4","LPMO light red 33_4","LPMO light red 18_4","LPMO light red 12_4",
for (i in 7:length(Filenames)){
  Namelist=Filenames[i]
  message(Namelist)
  source(paste("Background codes","\\","Peak extractor and modeller matrix new no blanks.R",sep=""))
  
}