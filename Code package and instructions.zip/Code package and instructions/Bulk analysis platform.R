source(paste("Background codes","\\","Function libary.R",sep=""))
Referencepot = -0.2582
Temperature= 298
ElectrodeArea=1
Coverageguess=200


ListofExtractedAnodic=list()
ListofExtractedCathodic=list()

ListofAnodicReconstruct=list()
ListofCathodicReconstruct=list()

ListofAnodic1=list()
ListofAnodic2=list()
ListofCathodic1=list()
ListofCathodic2=list()
ListofFittedparameters=list()

Filenames=c()

Scanrates=c(33)

for(i in 1:length(Scanrates)){
  file=paste(i, " Example LPMO ",Scanrates[i],"_4", sep="")
  Filenames=c(Filenames, file)
  }

for(i in 1:length(Filenames)){
  Filenames[i]=paste("LPMO","\\",Filenames[i], sep="")
  
}

GCblanknames=c()
Nanoblanknames=c()


for(i in 1:length(Scanrates)){
  file=paste(i, " Example GC blank ",Scanrates[i],"_4", sep="")
  GCblanknames=c(GCblanknames, file)
}

for(i in 1:length(GCblanknames)){
  GCblanknames[i]=paste("GC blank","\\",GCblanknames[i], sep="")
  
}


for(i in 1:length(Scanrates)){
  file=paste(i, " Example Nano blank ",Scanrates[i],"_4", sep="")
  Nanoblanknames=c(Nanoblanknames, file)
}

for(i in 1:length(Nanoblanknames)){
  Nanoblanknames[i]=paste("Nanotube blank","\\",Nanoblanknames[i], sep="")
  
}




for (i in 1:length(Filenames)){
  Namelist=Filenames[i]
  GCblank=GCblanknames[i]
  Nanoblank=Nanoblanknames[i]
  message(Namelist)
  source(paste("Background codes","\\","Peak extractor and modeller matrix new.R",sep=""))
  
}