p=0
j=0
u=0
l=0

for(i in 1:length(Namelist)){
  Funclist[[i]] = Process(Namelist[i])
  message(Namelist[i])  
  Func1 = Funclist[[i]]
  Forward=Chopf(Func1)
  
  smoothedforward=smoothdat(Forward[,1],Forward[,2],0.5)
  
  plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  lines(smoothedforward, type="l", col="forestgreen")
 
  StoredForward=Forward
  StoredSmoothedforward=smoothedforward
  
  Cropping = readline(prompt="Press 1 to apply a crop before smoothing, 0 to skip cropping: ") 
  
  if(Cropping == 1){
    for(b in 1:100) {if(l == 1) {break}
      else
    message(Forward[1,1])
    message(Forward[length(Forward[,1]),1])    
      
    Forward=StoredForward
    Forward=Clip(Forward)
    smoothedforward=smoothdat(Forward[,1],Forward[,2],0.5)
      
    plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
    minor.tick(nx=5, ny=5, tick.ratio=0.3)
    lines(StoredSmoothedforward, type="l", col="forestgreen")
    lines(StoredForward,type="l", lty=2)
   # lines(Forward,type="l",col="purple")
    lines(smoothedforward, type="l", col="red")

    l <- readline(prompt="Press 1 to accept crop, 0 to go try again: ") 
    
    }
    }
  
  Smoothing = readline(prompt="Press 1 to apply smoothing, 0 to skip smoothing: ") 

  if(Smoothing == 1){
    Forward = data.frame(as.vector(smoothedforward[[1]]),as.vector(smoothedforward[[2]]))
    colnames(Forward)=c("Voltage vs SHE (V)", "Current (�A)")
    plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
    minor.tick(nx=5, ny=5, tick.ratio=0.3)
    
  }
  

  for(n in 1:100) {if(p == 1) {break}
    else  
      
    plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
    minor.tick(nx=5, ny=5, tick.ratio=0.3)

  Forward = Clip(Forward)
  smoothedforward=smoothdat(Forward[,1],Forward[,2],0.5)
  plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
  lines(smoothedforward, type="l", col="forestgreen")
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  
  
  p <- readline(prompt="Press 1 to continue, 0 to go back: ") 
  }
  



for(n in 1:100) {if(j == 1) {break}
  else
  
 source(paste("Background codes","\\","fitbaselineusingforward matrix multiple.R",sep=""))
  
  plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  lines(smoothedforward, type="l")
  points(fitbaselineusingforward, col="red", lwd=3)
 # Forwardstored=Forward
  Baseline = SimpleClip(Forward,pairsofxpoints[[1]][1],pairsofxpoints[[1]][2])
  
  for(i in 2:regions){   
  Baseline = rbind(Baseline,SimpleClip(Forward,pairsofxpoints[[i]][1],pairsofxpoints[[i]][2]))
  }
  
  Baseline=Baseline[order(Baseline[,1]),]
 # Baseline=combineduplicate(Baseline)
  Voltagevalues= as.vector(as.matrix(Forward[,1])) 
  Voltage=Baseline[,1]
  Current = Baseline[,2]
  
  Baselinestored=Baseline
  
  Polyorder <- readline(prompt="Enter Polyorder: ")
  Polyorder = as.numeric(Polyorder)
  
  poly=lm(Current ~ poly(Voltage, Polyorder, raw=TRUE))
  
  Baselineprediction=predict(poly, list(Voltage=Voltagevalues))
  Baselinetoplot1 = data.frame(Voltagevalues,Baselineprediction)
  colnames(Baselinetoplot1)=c("BaselineVoltage (V)","BaselineCurrent (�A)")
  
  plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  lines(smoothedforward, type="l")
  points(fitbaselineusingforward, col="red", lwd=3)
#  lines(Baseline, col="blue")
  lines(Baselinetoplot1, col="red")
  
  j <- readline(prompt="Press 1 to continue, 0 to go back: ") 
}
  
  Forward=SimpleClip(Forward, max(fitbaselineusingforward[,1]),min(fitbaselineusingforward[,1]))
  Baselinetoplot1=SimpleClip(Baselinetoplot1, max(fitbaselineusingforward[,1]),min(fitbaselineusingforward[,1]))
  Voltagevalues= as.vector(as.matrix(Forward[,1])) 
  
  
  Extractedsignalcurrent=as.vector(as.matrix(Forward[,2]-Baselinetoplot1[,2]))
  Extractedsignalforward=data.frame(Voltagevalues,Extractedsignalcurrent)
  Extractedsignalforward=Extractedsignalforward[order(Extractedsignalforward[,1]),]
  
  colnames(Extractedsignalforward)=c("Voltage vs SHE (V)", "Current (�A)")
  
  x=as.vector(Extractedsignalforward[,1])
  y=as.vector(Extractedsignalforward[,2])
  smoothingSpline = smooth.spline(x, y, spar=0.1)
  predictvalues=predict(smoothingSpline, newdata=data.frame(x=x.new))
  
  plot(x,y, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=1, lty=1)
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  lines(predictvalues, col="red", lwd=2)
  lines(x,y, type="l")
  
  for(n in 1:100) {
    h <- readline(prompt="Press 1 to continue, 0 to fit a baseline on another peak: ") 
    
    if(h == 1) {break}
    else
    Additionalanodic=Extrapeakextractforward(Namelist)
    Additonalbaselinex=as.vector(Additionalanodic[,3])
    Additonalbaseliney=as.vector(Additionalanodic[,4])
    Additonalbaseline=data.frame(Additonalbaselinex,Additonalbaseliney)
    colnames(Additonalbaseline)=c("Voltage (V)","Current (�A)")
    
    
    Additionalanodic=Additionalanodic[,-4]
    Additionalanodic=Additionalanodic[,-3]
    
    Extractedsignalforward=rbind(Extractedsignalforward,Additionalanodic)  
    Extractedsignalforward=Extractedsignalforward[order(Extractedsignalforward[,1]),]
    
    colnames(Baselinetoplot1)=c("Voltage (V)","Current (�A)")
    
    Baselinetoplot1=rbind(Baselinetoplot1,Additonalbaseline)  
    Baselinetoplot1=Baselinetoplot1[order(Baselinetoplot1[,1]),]
    
    
    }
  
  rownames(Baselinetoplot1) =  1:nrow(Baselinetoplot1)
  Baselinetoplot1=Baselinetoplot1[order(Baselinetoplot1[,1]),]
  Baselinetoplot1=combineduplicatemin(Baselinetoplot1)
  Baselinetoplot1=Baselinetoplot1[order(Baselinetoplot1[,1]),]
  colnames(Baselinetoplot1)=c("Voltage vs SHE (V)", "Current (�A)")
  
  rownames(Extractedsignalforward) =  1:nrow(Extractedsignalforward)
  Extractedsignalforward=Extractedsignalforward[order(Extractedsignalforward[,1]),]
  Extractedsignalforward=combineduplicate(Extractedsignalforward)
  Extractedsignalforward=Extractedsignalforward[order(Extractedsignalforward[,1]),]
  
  colnames(Extractedsignalforward)=c("Voltage vs SHE (V)", "Current (�A)")
  
  x=as.vector(Extractedsignalforward[,1])
  y=as.vector(Extractedsignalforward[,2])
  smoothingSpline = smooth.spline(x, y, spar=0.1)
  predictvalues=predict(smoothingSpline, newdata=data.frame(x=x.new))
  
  plot(x,y, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=1, lty=1)
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  lines(predictvalues, col="red", lwd=2)
  lines(x,y, type="l")
  
  for(n in 1:100) {if(u == 1) {break}
    else
      
  source(paste("Background codes","\\","Plot points on forward scan matrix.R",sep=""))
    

  plot(x,y, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=1, lty=1)
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  points(plotpointsforward,lwd=5, col="yellow")
  lines(predictvalues, col="red", lwd=2)
  lines(x,y, type="l")
  
  u <- readline(prompt="Press 1 to continue, 0 to go back: ") 
  
  }
  #message(Scanrates[i])
  Extractedpeaksforward = predictvalues  
}
  