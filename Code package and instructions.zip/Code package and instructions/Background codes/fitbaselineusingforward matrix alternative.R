Fitbaselineusingforward=c()
for (i in 1:2){
  Fitbaselineusingforward = c(Fitbaselineusingforward, as.numeric(readline(prompt=paste("Enter Fitbaselineusingforward",i, ": ", sep=""))))
  
}


xpoints=rev(Fitbaselineusingforward)
xpointstoplot=c()
ypoints=c()



for(i in 1:length(smoothedforward[[1]])){
  
  value=smoothedforward[[1]][i]
  
  if (value >= Fitbaselineusingforward[1]){
    xpointstoplot=c(xpointstoplot,as.numeric(smoothedforward[[1]][i]))
    ypoints=c(ypoints,smoothedforward[[2]][i])
    
  }
  
  if (value <= Fitbaselineusingforward[2]){
    xpointstoplot=c(xpointstoplot,as.numeric(smoothedforward[[1]][i]))
    ypoints=c(ypoints,smoothedforward[[2]][i])
    
  }
  
}
fitbaselineusingforward=data.frame(xpointstoplot,ypoints)
colnames(fitbaselineusingforward)=c("Voltage vs SHE (V)", "Current (�A)")
fitbaselineusingforward=fitbaselineusingforward[order("Voltage vs SHE (V)"),]

