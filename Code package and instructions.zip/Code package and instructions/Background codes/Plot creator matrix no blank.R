smoothmainplot=as.numeric(readline(prompt = "Press 1 if you want to smooth the main plot, 0 to skip this: "))

if (smoothmainplot == 1) {

for(i in 1:length(Namelist)){
  Funclist[[i]] = Process(Namelist[i])
  message(Namelist[i])  
  Func1 = Funclist[[i]]
  Forward=Chopf(Func1)
  
  smoothedforward=smoothdat(Forward[,1],Forward[,2],0.5)
  smoothedforward = data.frame(as.vector(smoothedforward[[1]]),as.vector(smoothedforward[[2]]))
  colnames(smoothedforward)=c("Voltage vs SHE (V)", "Current (�A)")
smoothedforward= smoothedforward[order(smoothedforward[,1]),]
}


for(i in 1:length(Namelist)){
  Funclist[[i]] = Process(Namelist[i])
  message(Namelist[i])  
  Func1 = Funclist[[i]]
  Backward = Chopb(Func1)
  
  plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  
  smoothedbackward=smoothdat(Backward[,1],Backward[,2],0.5)
  smoothedbackward = data.frame(as.vector(smoothedbackward[[1]]),as.vector(smoothedbackward[[2]]))
  colnames(smoothedbackward)=c("Voltage vs SHE (V)", "Current (�A)")
  smoothedbackward= smoothedbackward[order(-smoothedbackward[,1]),]
  
  
}
#Namelist="LPMO 63_4"
smoothedplot=rbind(smoothedforward,smoothedbackward)
Func1=smoothedplot



}
  
  if (smoothmainplot != 1) {
for(i in 1:length(Namelist)){
  Funclist[[i]] = Process(Namelist[i])
  message(Namelist[i])  
  Func1 = Funclist[[i]]}
  

}

end=Func1[length(Func1[,1]),]
start=Func1[1,]

Fullcircx=c(start[,1],start[,1],end[,1])
Fullcircy=c(end[,2],start[,2],start[,2])

Extractedpeaksforwarddfx=unlist(Extractedpeaksforward[[1]][1])
Extractedpeaksforwarddfy=unlist(Extractedpeaksforward[[1]][2])

Extractedpeaksbackwardsdfx=unlist(Extractedpeaksbackwards[[1]][1])
Extractedpeaksbackwardsdfy=unlist(Extractedpeaksbackwards[[1]][2])

h=0

scalefactor=1

graphcol=c("forestgreen","Orange","cornflowerblue","deeppink","coral1")

legendentry=c()
lwdvec=c()
ltyvec=c()
colvec=c()

for (i in 1:length(NumsigA)){
  legendpart=paste("Simulated signal ",NumsigA[i])
  legendentry=c(legendentry,legendpart)
  ltyvec=c(ltyvec,1)
  lwdvec=c(lwdvec,2)
  colvec=c(colvec,graphcol[i])
  
}

plot(Func1, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2)
minor.tick(nx=5, ny=5, tick.ratio=0.3)
lines(Fullcircx,Fullcircy, lwd=2)


lines(Func1, lwd=2)



lines(Baselinetoplot1, col="red")
lines(Baselinetoplot2, col="red")

#lines(Extractedpeaksforwarddfx,Extractedpeaksforwarddfy*scalefactor, col="cyan3",lwd=2)
#lines(Extractedpeaksbackwardsdfx,Extractedpeaksbackwardsdfy*scalefactor, col="cyan3",lwd=2)
lines(Extractedpeaksforward[[1]],Reconstructedanodic*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
for(g in 1:length(namevec)){
  
  o=length(namevec)-g+1
  lines(Extractedpeaksforward[[1]],PredictedAnodicIlist[[o]]*scalefactor, col=graphcol[o],lwd=2)
  lines(Extractedpeaksbackwards[[1]],PredictedCathIlist[[o]]*scalefactor, col=graphcol[o],lwd=2)
  
}
lines(Extractedpeaksforward[[1]],Reconstructedanodic*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
lines(Extractedpeaksbackwards[[1]],ReconstructedCath*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
lines(Extractedpeaksforward[[1]],Extractedpeaksforward[[2]]*scalefactor, col="black", lwd=2, lty=2)
lines(Extractedpeaksbackwards[[1]],Extractedpeaksbackwards[[2]]*scalefactor, col="black", lwd=2, lty=2)

legend("topleft", legend=c("Nanotubes+LPMO","Extracted signal", "Baseline",legendentry, "Reconstructed signal"),
       col=c("Black","Black","Red",colvec, "purple"), lwd=c(2,2,1,2,2,lwdvec), lty=c(1,2,1,2,4,ltyvec), cex=0.9, bty="n")




for(i in 1:100){
  if(h==1){break}
  else

scalefactor=as.numeric(readline(prompt = "Enter scale factor for extracted peaks?: "))


  plot(Func1, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2)
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  lines(Fullcircx,Fullcircy, lwd=2)
  
 
  lines(Func1, lwd=2)
  
  
  
  lines(Baselinetoplot1, col="red")
  lines(Baselinetoplot2, col="red")
  
  #lines(Extractedpeaksforwarddfx,Extractedpeaksforwarddfy*scalefactor, col="cyan3",lwd=2)
  #lines(Extractedpeaksbackwardsdfx,Extractedpeaksbackwardsdfy*scalefactor, col="cyan3",lwd=2)
  lines(Extractedpeaksforward[[1]],Reconstructedanodic*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
  for(g in 1:length(namevec)){
    o=length(namevec)-g+1
    lines(Extractedpeaksforward[[1]],PredictedAnodicIlist[[o]]*scalefactor, col=graphcol[o],lwd=2)
    lines(Extractedpeaksbackwards[[1]],PredictedCathIlist[[o]]*scalefactor, col=graphcol[o],lwd=2)
    
  }
  lines(Extractedpeaksforward[[1]],Reconstructedanodic*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
  lines(Extractedpeaksbackwards[[1]],ReconstructedCath*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
  lines(Extractedpeaksforward[[1]],Extractedpeaksforward[[2]]*scalefactor, col="black", lwd=2, lty=2)
  lines(Extractedpeaksbackwards[[1]],Extractedpeaksbackwards[[2]]*scalefactor, col="black", lwd=2, lty=2)
  
  legend("topleft", legend=c("Nanotubes+LPMO","Extracted signal", "Baseline",legendentry, "Reconstructed signal"),
         col=c("Black","Black","Red",colvec, "purple"), lwd=c(2,2,1,2,2,lwdvec), lty=c(1,2,1,2,4,ltyvec), cex=0.9, bty="n")
  
  
  
h=as.numeric(readline(prompt = "Press 1 to accept the graph, 0 to re-apply a scale factor: "))
}

pdf(paste(Destination,Designation,".pdf", step=""),width = 5, height = 5)
plot(Func1, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2)
minor.tick(nx=5, ny=5, tick.ratio=0.3)
lines(Fullcircx,Fullcircy, lwd=2)


lines(Func1, lwd=2)



lines(Baselinetoplot1, col="red")
lines(Baselinetoplot2, col="red")

#lines(Extractedpeaksforwarddfx,Extractedpeaksforwarddfy*scalefactor, col="cyan3",lwd=2)
#lines(Extractedpeaksbackwardsdfx,Extractedpeaksbackwardsdfy*scalefactor, col="cyan3",lwd=2)
lines(Extractedpeaksforward[[1]],Reconstructedanodic*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
for(g in 1:length(namevec)){
  o=length(namevec)-g+1
  lines(Extractedpeaksforward[[1]],PredictedAnodicIlist[[o]]*scalefactor, col=graphcol[o],lwd=2)
  lines(Extractedpeaksbackwards[[1]],PredictedCathIlist[[o]]*scalefactor, col=graphcol[o],lwd=2)
  
}
lines(Extractedpeaksforward[[1]],Reconstructedanodic*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
lines(Extractedpeaksbackwards[[1]],ReconstructedCath*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
lines(Extractedpeaksforward[[1]],Extractedpeaksforward[[2]]*scalefactor, col="black", lwd=2, lty=2)
lines(Extractedpeaksbackwards[[1]],Extractedpeaksbackwards[[2]]*scalefactor, col="black", lwd=2, lty=2)

legend("topleft", legend=c("Nanotubes+LPMO","Extracted signal", "Baseline",legendentry, "Reconstructed signal"),
       col=c("Black","Black","Red",colvec, "purple"), lwd=c(2,2,1,2,2,lwdvec), lty=c(1,2,1,2,4,ltyvec), cex=0.9, bty="n")



dev.off()