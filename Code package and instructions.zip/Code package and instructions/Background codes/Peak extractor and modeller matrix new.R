Colours=c("Black","blue","red","purple","brown","orange","grey53","green","pink","yellow")
#Namelist = readline(prompt="Enter file name")
#Namelist = readline(prompt="Enter file name: ")
#Referencepot = as.numeric(readline(prompt="Enter reference potential vs SHE: "))

for(i in 1:length(Namelist)){
  Previewplot = Process(Namelist[i])
  plot(Previewplot, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
}

Experimentnumber = as.numeric(readline(prompt="Enter experiment number: "))


Faraday=96485.3365
Gas=8.3144621
#Temperature= as.numeric(readline(prompt="Enter temperature in K: "))
Scanrate=as.numeric(readline(prompt="Enter scan rate in V s^-1: "))  # in V s-1



Numsig=as.numeric(readline(prompt="How many signals are there in the region of interest?: "))

NumsigA=seq(1, Numsig, by=1)
ParameterlistCath= c("NumelectronsCathodic","Cathodicpeakpot","CathodicAppelectrons","CathodicElectrodecoverage")
ParameterlistAnod= c("Numelectronsanodic","Anodicpeakpot","AnodicAppelectrons","AnodicElectrodecoverage")


namevec = c()

for(i in 1:length(NumsigA)){
  namevec=c(namevec, paste("Signal ", NumsigA[i], sep=""))
}


ParameterinputCath=matrix(1, nrow=length(ParameterlistCath), ncol=Numsig)
rownames(ParameterinputCath)=ParameterlistCath
colnames(ParameterinputCath)=namevec

ParameterinputCath=as.data.frame(ParameterinputCath)

ParameterinputAnod=matrix(1, nrow=length(ParameterlistAnod), ncol=Numsig)
rownames(ParameterinputAnod)=ParameterlistAnod
colnames(ParameterinputAnod)=namevec

ParameterinputAnod=as.data.frame(ParameterinputAnod)
ParameterinputCath=as.data.frame(ParameterinputCath)

#for(i in 1:length(Numsig)){
#  message(paste("Signal ", i))
#nforcouple=as.numeric(readline(prompt="n=?: "))
#ParameterinputAnod[1,i]=nforcouple
#parameterinputCath[1,i]=nforcouple
#}
#These hashed-out lines above would have to be used to simulate
#n=2 electrode redox processes

ParameterinputAnod[4,]=Coverageguess*(10^-12)
ParameterinputCath[4,]=Coverageguess*(10^-12)

Funclist = list()
Extractedpeaksforward = list()
Extractedpeaksbackwards = list()
Dataframenames=c()
for (i in 1:length(Namelist)){
  Dataframenames=c(Dataframenames,Namelist[i])
}


IterationnumberAnodic=c()
IterationR2Anodic=c()

source(paste("Background codes","\\","Baseline plotter1 matrix.R",sep=""))

for (i in 1:length(Anodicpeakpot)){
  ParameterinputAnod[2,i]=Anodicpeakpot[i]
}

Coverageguess=Findcoverage(data.frame(Extractedpeaksforward[[1]],Extractedpeaksforward[[2]]),ElectrodeArea,Scanrate*1000,1)


ParameterinputAnod[4,]=Coverageguess*(10^-12)
ParameterinputCath[4,]=Coverageguess*(10^-12)

source(paste("Background codes","\\","Anodic peak modeller matrix new.R",sep=""))

StoredR2=SumR2

breaker=0
for(u in 1:100){
  
if (breaker==1){break}
  
  else
    
    plot(Extractedpeaksforward[[1]],Reconstructedanodic, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=2)
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  for (i in 1:length(namevec)){
    #lines(Extractedsignalforward[,1],PredictedpeakAnod[[i]])
    lines(Extractedpeaksforward[[1]],PredictedAnodicIlist[[i]])
  }
  lines(Extractedsignalforward[,1],Extractedsignalforward[,2], col="red")
  lines(Extractedpeaksforward[[1]],Extractedpeaksforward[[2]], col="blue",lwd=2)
  
    
    for (o in 1:length(Anodicpeakpot)){
      message(paste("Current coverage (signal", o, ")",  "= ", ParameterinputAnod[4,o],sep=""))
      factorsig=as.numeric(readline(prompt="Enter factor to scale signal coverage by :"))
      ParameterinputAnod[4,o]=ParameterinputAnod[4,o]*factorsig
    }

    message("to get out of local minima we'll reselect peak locations")
    for (s in 1:length(Anodicpeakpot)){
      message(paste("Current location (signal", s, ")",  "= ", ParameterinputAnod[2,s],sep=""))

    }   
  for(n in 1:100) {if(u == 1) {break}
    else
    
    dev.off(dev.list()["RStudioGD"])
    
 
    
    plot(x,y, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=1, lty=1)
    minor.tick(nx=5, ny=5, tick.ratio=0.3)    
    source(paste("Background codes","\\","Plot points on forward scan matrix.R",sep=""))
    
    
    plot(x,y, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=1, lty=1)
    minor.tick(nx=5, ny=5, tick.ratio=0.3)
    points(plotpointsforward,lwd=5, col="yellow")
    lines(predictvalues, col="red", lwd=2)
    lines(x,y, type="l")
    
    u <- readline(prompt="Press 1 to continue, 0 to go back: ") 
    
  }  

    for (o in 1:length(Anodicpeakpot)){
      ParameterinputAnod[2,o]=Anodicpeakpot[o]
    }
  
  source(paste("Background codes","\\","Anodic peak modeller matrix new.R",sep=""))
  
  StoredR2=SumR2
  
        
for (d in 1:600){

  source(paste("Background codes","\\","Anodic peak modeller matrix new.R",sep=""))
  
  if (SumR2 > StoredR2) {
    ParameterinputAnod=ParameterinputstoredAnod
  }


  
else{StoredR2=SumR2}
  
IterationnumberAnodic=c(IterationnumberAnodic,d)
IterationR2Anodic=c(IterationR2Anodic,sum(R2))
message(d)


}
  par(mfrow=c(1,2))
  plot(IterationnumberAnodic,IterationR2Anodic, xlab="Iteration", ylab="SumR2")
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  
  plot(Extractedpeaksforward[[1]],Reconstructedanodic, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=2)
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  lines(Extractedsignalforward[,1],Extractedsignalforward[,2], col="red")
  lines(Extractedpeaksforward[[1]],Extractedpeaksforward[[2]], col="blue",lwd=2)
  
  for (i in 1:length(namevec)){
    #lines(Extractedsignalforward[,1],PredictedpeakAnod[[i]])
    lines(Extractedpeaksforward[[1]],PredictedAnodicIlist[[i]])
  }
  
  
  
  breaker=as.numeric(readline(prompt="Press 0 to continue optimisation, press 1 to proceed: "))

  }

par(mfrow=c(1,2))
plot(IterationnumberAnodic,IterationR2Anodic, xlab="Iteration", ylab="SumR2")
minor.tick(nx=5, ny=5, tick.ratio=0.3)

plot(Extractedpeaksforward[[1]],Reconstructedanodic, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=2)
minor.tick(nx=5, ny=5, tick.ratio=0.3)
lines(Extractedsignalforward[,1],Extractedsignalforward[,2], col="red")
lines(Extractedpeaksforward[[1]],Extractedpeaksforward[[2]], col="blue",lwd=2)
for (i in 1:length(namevec)){
#lines(Extractedsignalforward[,1],PredictedpeakAnod[[i]])
lines(Extractedpeaksforward[[1]],PredictedAnodicIlist[[i]])
}



p <- readline(prompt="Press any key to continue: ")

dev.off(dev.list()["RStudioGD"])

IterationnumberCathodic=c()
IterationR2Cathodic=c()

source(paste("Background codes","\\","Baseline plotter2 matrix.R",sep=""))

for (i in 1:length(Cathodicpeakpot)){
  ParameterinputCath[2,i]=Cathodicpeakpot[i]
}


source(paste("Background codes","\\","Cathodic peak modeller matrix new.R",sep=""))

StoredR2=SumR2


breaker=0
for(u in 1:100){
  
  if (breaker==1){break}
  
  else
    
    plot(Extractedpeaksbackwards[[1]],ReconstructedCath, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=2)
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  for (i in 1:length(namevec)){
    lines(Extractedpeaksbackwards[[1]],PredictedCathIlist[[i]])
  }
  lines(Extractedsignalbackward[,1],Extractedsignalbackward[,2], col="red")
  lines(Extractedpeaksbackwards[[1]],Extractedpeaksbackwards[[2]], col="blue",lwd=2)
  
  
  for (o in 1:length(Cathodicpeakpot)){
    message(paste("Current coverage (signal", o, ")",  "= ", ParameterinputCath[4,o],sep=""))
    factorsig=as.numeric(readline(prompt="Enter factor to scale signal coverage by :"))
    ParameterinputCath[4,o]=ParameterinputCath[4,o]*factorsig
  }
  
  message("to get out of local minima we'll reselect peak locations")
   
  for (s in 1:length(Anodicpeakpot)){
      message(paste("Current location (signal", s, ")",  "= ", ParameterinputCath[2,s],sep=""))

    }  
  for(n in 1:100) {if(u == 1) {break}
    else
      
      dev.off(dev.list()["RStudioGD"])
    
 
    
    plot(x,y, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=1, lty=1)
    minor.tick(nx=5, ny=5, tick.ratio=0.3)    
    source(paste("Background codes","\\","Plot points on backward scan matrix.R",sep=""))
    
    
    plot(x,y, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=1, lty=1)
    minor.tick(nx=5, ny=5, tick.ratio=0.3)
    points(plotpointsbackward,lwd=5, col="yellow")
    lines(predictvalues, col="red", lwd=2)
    lines(x,y, type="l")
    
    u <- readline(prompt="Press 1 to continue, 0 to go back: ") 
    
  }  
  
  for (o in 1:length(Cathodicpeakpot)){
    ParameterinputCath[2,o]=Cathodicpeakpot[o]
  }
  
  source(paste("Background codes","\\","Cathodic peak modeller matrix new.R",sep=""))
  
  StoredR2=SumR2
  
  
  for (d in 1:600){
    
    source(paste("Background codes","\\","Cathodic peak modeller matrix new.R",sep=""))
    
    if (SumR2 > StoredR2) {
      ParameterinputCath=ParameterinputstoredCath
    }
    
    
    
    else{StoredR2=SumR2}
    
    IterationnumberCathodic=c(IterationnumberCathodic,d)
    IterationR2Cathodic=c(IterationR2Cathodic,sum(R2))
    message(d)
    
    
  }
  par(mfrow=c(1,2))
  plot(IterationnumberCathodic,IterationR2Cathodic, xlab="Iteration", ylab="SumR2")
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  
  plot(Extractedpeaksbackwards[[1]],ReconstructedCath, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=2)
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  for (i in 1:length(namevec)){
    lines(Extractedpeaksbackwards[[1]],PredictedCathIlist[[i]])
  }
  lines(Extractedsignalbackward[,1],Extractedsignalbackward[,2], col="red")
  lines(Extractedpeaksbackwards[[1]],Extractedpeaksbackwards[[2]], col="blue",lwd=2)
  
  
  
  breaker=as.numeric(readline(prompt="Press 0 to continue optimisation, press 1 to proceed: "))
  
}

par(mfrow=c(1,2))
plot(IterationnumberCathodic,IterationR2Cathodic, xlab="Iteration", ylab="SumR2")
minor.tick(nx=5, ny=5, tick.ratio=0.3)

plot(Extractedpeaksbackwards[[1]],ReconstructedCath, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=2)
minor.tick(nx=5, ny=5, tick.ratio=0.3)
for (i in 1:length(namevec)){
  lines(Extractedpeaksbackwards[[1]],PredictedCathIlist[[i]])
}
lines(Extractedsignalbackward[,1],Extractedsignalbackward[,2], col="red")
lines(Extractedpeaksbackwards[[1]],Extractedpeaksbackwards[[2]], col="blue",lwd=2)



p <- readline(prompt="Press any key to continue: ")

dev.off(dev.list()["RStudioGD"])



Designation=readline(prompt="Enter shorthand name for file: ")
dir.create(Designation)
Destination=paste(Designation,"\\",sep="")

FittedparametersAnod=as.data.frame(ParameterinputAnod)
FittedparametersCath=as.data.frame(ParameterinputCath)

Formalpotentials=c()
for(f in 1:length(FittedparametersAnod[1,])){
  Formalpotential=FittedparametersAnod[2,f]+FittedparametersCath[2,f]
  Formalpotential=Formalpotential/2
  Formalpotentials=c(Formalpotentials,Formalpotential)
}

Formalpotentials=data.frame(Formalpotentials)
Formalpotentials=t(Formalpotentials)
colnames(Formalpotentials)=namevec

Cathodicintensities=c()
Anodicintensities=c()


for(f in 1:length(FittedparametersAnod[1,])){
  Cathodicintensity=min(PredictedCathIlist[[f]])
  Cathodicintensities=c(Cathodicintensities,Cathodicintensity)
  
  Anodicintensity=max(PredictedAnodicIlist[[f]])
  Anodicintensities=c(Anodicintensities,Anodicintensity)

}

Cathodicintensities=data.frame(Cathodicintensities)
Cathodicintensities=t(Cathodicintensities)
colnames(Cathodicintensities)=namevec

Anodicintensities=data.frame(Anodicintensities)
Anodicintensities=t(Anodicintensities)
colnames(Anodicintensities)=namevec

Anodicpeakvoltages=c()
cathodicpeakvoltages=c()

for(f in 1:length(FittedparametersAnod[1,])){

  xcoordssim=as.vector(Extractedpeaksforward[[1]])  
  ycoordsim=as.vector(PredictedAnodicIlist[[f]])
  
  SimulatedAnodic=data.frame(xcoordssim,ycoordsim)
  colnames(SimulatedAnodic)=c("Voltage vs SHE (V)", "Current (A)")
  
  AnodicPeakvoltage=Peakanodic(SimulatedAnodic)
  Anodicpeakvoltages=c(Anodicpeakvoltages,AnodicPeakvoltage)
  
  
  write.csv(SimulatedAnodic, paste(Destination,Designation,"Signal",f,"SimulatedAnodic.csv"))
  
  xcoordssim=as.vector(Extractedpeaksbackwards[[1]])  
  ycoordsim=as.vector(PredictedCathIlist[[f]])
  
  SimulatedCathodic=data.frame(xcoordssim,ycoordsim)
  colnames(SimulatedCathodic)=c("Voltage vs SHE (V)", "Current (A)")
  
  CathodicPeakvoltage=Peakcathoic(SimulatedCathodic)
  cathodicpeakvoltages=c(cathodicpeakvoltages,CathodicPeakvoltage)
  
  
  write.csv(SimulatedCathodic, paste(Destination,Designation,"Signal",f,"SimulatedCathodic.csv"))
  
}

colnames(Extractedsignalbackward)=c("Voltage vs SHE (V)", "Current (�A)")
colnames(Extractedsignalforward)=c("Voltage vs SHE (V)", "Current (�A)")

write.csv(Extractedsignalbackward, paste(Destination,Designation,"Extractedsignalbackward.csv"))
write.csv(Extractedsignalforward, paste(Destination,Designation,"Extractedsignalforward.csv"))


cathodicpeakvoltages=data.frame(cathodicpeakvoltages)
cathodicpeakvoltages=t(cathodicpeakvoltages)
colnames(cathodicpeakvoltages)=namevec

Anodicpeakvoltages=data.frame(Anodicpeakvoltages)
Anodicpeakvoltages=t(Anodicpeakvoltages)
colnames(Anodicpeakvoltages)=namevec


Fittedparameters=rbind(FittedparametersAnod, FittedparametersCath, Formalpotentials, Anodicintensities, Cathodicintensities, cathodicpeakvoltages, Anodicpeakvoltages)




Extraparameters1=data.frame(c("Scan rate (V s-1)"), Scanrate, stringsAsFactors = FALSE)
Extraparameters2=data.frame(c("Experiment number"), Experimentnumber, stringsAsFactors = FALSE)
Extraparameters3=data.frame(c("Electrode area (cm^-2)"), ElectrodeArea, stringsAsFactors = FALSE)


colnames(Extraparameters1)=c("Parameter","Value")
colnames(Extraparameters2)=c("Parameter","Value")
colnames(Extraparameters3)=c("Parameter","Value")



Extraparameters=rbind(Extraparameters1,Extraparameters2,Extraparameters3)


write.csv(Fittedparameters, paste(Destination,"Fittedparameters.csv"))
write.csv(Extraparameters, paste(Destination,"Extraparameters.csv"))

save.image(file = paste(Destination,Designation,".RData", sep=""))

#dev.off(dev.list()["RStudioGD"])

Baselinetoplot1=Baselinetoplot1[order(Baselinetoplot1[,1]),]
Baselinetoplot2=Baselinetoplot2[order(Baselinetoplot2[,1]),]

write.csv(Baselinetoplot1, paste(Destination,Designation,"Signal",f,"Baselinetoplot1.csv"))

write.csv(Baselinetoplot2, paste(Destination,Designation,"Signal",f,"Baselinetoplot2.csv"))



source(paste("Background codes","\\","Plot creator matrix.R",sep=""))
