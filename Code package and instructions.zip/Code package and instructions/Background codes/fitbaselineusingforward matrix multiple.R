regions= readline(prompt="how many regions do you want to take datapoints from: ") 
pairsofxpoints=list()
xpoints=c()

for (i in 1:regions){
  Fitbaselineusingforward=c()
  
  message(paste("Define region",i))
  for(g in 1:2){
  Fitbaselineusingforward = c(Fitbaselineusingforward, as.numeric(readline(prompt=paste("Enter Fitbaselineusingforward",i, ": ", sep=""))))

  }
  xpointpair=Fitbaselineusingforward
  pairsofxpoints[[i]]=xpointpair
  xpoints=c(xpoints,xpointpair)
}

xpointstoplot=c()
ypoints=c()


for(j in 1:length(xpoints)){

    differences=c()

for(i in 1:length(smoothedforward[[1]])){
  
  value=smoothedforward[[1]][i]
  difference=abs(value-xpoints[j])
  differences=c(differences,difference)
}

  for(k in 1:length(smoothedforward[[1]])){
    
    if (differences[k] == min(differences)){
      xpointstoplot=c(xpointstoplot,as.numeric(smoothedforward[[1]][k]))
      ypoints=c(ypoints,smoothedforward[[2]][k])
    }
    
  }
  

  }

fitbaselineusingforward=data.frame(xpointstoplot,ypoints)

