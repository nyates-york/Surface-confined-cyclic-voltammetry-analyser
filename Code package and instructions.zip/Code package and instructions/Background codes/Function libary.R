combineduplicate=function(data){
  
  x=data[,1]
  y=data[,2]
  
  Vectorx=c()
  Vectory=c()
  
  for (i in 2:(length(x))){
    # message(i)
    u=i-1
    
    value1=x[i]
    
    value2=x[u]
    
    
    if (value1 != value2){
      Vectorx=c(Vectorx,x[i])
      Vectory=c(Vectory,y[i])
      message("clear")
    }
    
    else
      message("found 1")
    Vectory=Vectory[-length(Vectory)]
    if (abs(y[u])>abs(y[i])){
      Vectory=c(Vectory,y[u])
    }
    else
      Vectory=c(Vectory,y[i])
    
    
  }
  
  newdataframe=data.frame(Vectorx,Vectory)
  return(newdataframe)
}

combineduplicatemin=function(data){
  
  x=data[,1]
  y=data[,2]
  
  Vectorx=c()
  Vectory=c()
  
  for (i in 2:(length(x))){
    # message(i)
    u=i-1
    
    value1=x[i]
    
    value2=x[u]
    
    
    if (value1 != value2){
      Vectorx=c(Vectorx,x[i])
      Vectory=c(Vectory,y[i])
      message("clear")
    }
    
    else
      message("found 1")
    Vectory=Vectory[-length(Vectory)]
    if (abs(y[u])<abs(y[i])){
      Vectory=c(Vectory,y[u])
    }
    else
      Vectory=c(Vectory,y[i])
    
    
  }
  
  newdataframe=data.frame(Vectorx,Vectory)
  return(newdataframe)
}



Extrapeakextractforward=function(Namelist){
  p=0
  j=0
  u=0
  
  for(i in 1:length(Namelist)){
    Funclist[[i]] = Process(Namelist[i])
    message(Namelist[i])  
    Func1 = Funclist[[i]]
    Forward=Chopf(Func1)
    
    smoothedforward=smoothdat(Forward[,1],Forward[,2],0.5)
    plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
    minor.tick(nx=5, ny=5, tick.ratio=0.3)
    lines(smoothedforward, type="l", col="forestgreen")
    StoredForward=Forward
    StoredSmoothedforward=smoothedforward
    
    
    Cropping = readline(prompt="Press 1 to apply a crop before smoothing, 0 to skip cropping: ") 
    l=0
    if(Cropping == 1){
      for(b in 1:100) {if(l == 1) {break}
        else
          message(Forward[1,1])
        message(Forward[length(Forward[,1]),1])    
        
        Forward=StoredForward
        Forward=Clip(Forward)
        smoothedforward=smoothdat(Forward[,1],Forward[,2],0.5)
        
        plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
        minor.tick(nx=5, ny=5, tick.ratio=0.3)
        lines(StoredSmoothedforward, type="l", col="forestgreen")
        lines(StoredForward,type="l", lty=2)
        # lines(Forward,type="l",col="purple")
        lines(smoothedforward, type="l", col="red")
        
        l <- readline(prompt="Press 1 to accept crop, 0 to go try again: ") 
        
      }
    }
    
    
    Smoothing = readline(prompt="Press 1 to apply smoothing, 0 to skip smoothing: ") 
    
    if(Smoothing == 1){
      Forward = data.frame(as.vector(smoothedforward[[1]]),as.vector(smoothedforward[[2]]))
      colnames(Forward)=c("Voltage vs SHE (V)", "Current (�A)")
      plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
      minor.tick(nx=5, ny=5, tick.ratio=0.3)
      
    }
    
    
    for(n in 1:100) {if(p == 1) {break}
      else  
        
        plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)")
      minor.tick(nx=5, ny=5, tick.ratio=0.3)
      
      Forward = Clip(Forward)
      smoothedforward=smoothdat(Forward[,1],Forward[,2],0.5)
      plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)")
      lines(smoothedforward, type="l", col="forestgreen")
      minor.tick(nx=5, ny=5, tick.ratio=0.3)
      
      
      p <- readline(prompt="Press 1 to continue, 0 to go back: ") 
    }
    message("got to here0")
    
    
    
    for(n in 1:100) {if(j == 1) {break}
      else
        message("got to here")
      #source(paste("Background codes","\\","fitbaselineusingforward matrix multiple.R",sep=""))
      
      regions= readline(prompt="how many regions do you want to take datapoints from: ") 
      pairsofxpoints=list()
      xpoints=c()
      
      for (i in 1:regions){
        Fitbaselineusingforward=c()
        
        message(paste("Define region",i))
        for(g in 1:2){
          Fitbaselineusingforward = c(Fitbaselineusingforward, as.numeric(readline(prompt=paste("Enter Fitbaselineusingforward",i, ": ", sep=""))))
          
        }
        xpointpair=Fitbaselineusingforward
        pairsofxpoints[[i]]=xpointpair
        xpoints=c(xpoints,xpointpair)
      }
      
      xpointstoplot=c()
      ypoints=c()
      
      
      for(j in 1:length(xpoints)){
        
        differences=c()
        
        for(i in 1:length(smoothedforward[[1]])){
          
          value=smoothedforward[[1]][i]
          difference=abs(value-xpoints[j])
          differences=c(differences,difference)
        }
        
        for(k in 1:length(smoothedforward[[1]])){
          
          if (differences[k] == min(differences)){
            xpointstoplot=c(xpointstoplot,as.numeric(smoothedforward[[1]][k]))
            ypoints=c(ypoints,smoothedforward[[2]][k])
          }
          
        }
        
        
      }
      
      fitbaselineusingforward=data.frame(xpointstoplot,ypoints)
      
      
      plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
      minor.tick(nx=5, ny=5, tick.ratio=0.3)
      lines(smoothedforward, type="l")
      points(fitbaselineusingforward, col="red", lwd=3)
      message("got to here2")
      
      Baseline = SimpleClip(Forward,pairsofxpoints[[1]][1],pairsofxpoints[[1]][2])
      
      for(i in 2:regions){   
        Baseline = rbind(Baseline,SimpleClip(Forward,pairsofxpoints[[i]][1],pairsofxpoints[[i]][2]))
      }  
      #      Baseline=combineduplicate(Baseline)
      
      Voltagevalues= as.vector(as.matrix(Forward[,1])) 
      Voltage=Baseline[,1]
      Current = Baseline[,2]
      
      Baselinestored=Baseline
      
      Polyorder <- readline(prompt="Enter Polyorder: ")
      Polyorder = as.numeric(Polyorder)
      
      poly=lm(Current ~ poly(Voltage, Polyorder, raw=TRUE))
      
      Baselineprediction=predict(poly, list(Voltage=Voltagevalues))
      Baselinetoplot1 = data.frame(Voltagevalues,Baselineprediction)
      colnames(Baselinetoplot1)=c("BaselineVoltage (V)","BaselineCurrent (�A)")
      
      plot(Forward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
      minor.tick(nx=5, ny=5, tick.ratio=0.3)
      lines(smoothedforward, type="l")
      points(fitbaselineusingforward, col="red", lwd=3)
      #  lines(Baseline, col="blue")
      lines(Baselinetoplot1, col="red")
      
      j <- readline(prompt="Press 1 to continue, 0 to go back: ") 
    }
    
    Forward=SimpleClip(Forward, max(fitbaselineusingforward[,1]),min(fitbaselineusingforward[,1]))
    Baselinetoplot1=SimpleClip(Baselinetoplot1, max(fitbaselineusingforward[,1]),min(fitbaselineusingforward[,1]))
    Voltagevalues= as.vector(as.matrix(Forward[,1])) 
    
    
    Extractedsignalcurrent=as.vector(as.matrix(Forward[,2]-Baselinetoplot1[,2]))
    Extractedsignalforward=data.frame(Voltagevalues,Extractedsignalcurrent, Baselinetoplot1[,1],Baselinetoplot1[,2])
    Extractedsignalforward=Extractedsignalforward[order(Extractedsignalforward[,1]),]
    
    x=as.vector(Extractedsignalforward[,1])
    y=as.vector(Extractedsignalforward[,2])
    smoothingSpline = smooth.spline(x, y, spar=0.1)
    predictvalues=predict(smoothingSpline, newdata=data.frame(x=x.new))
    
    #    plot(x,y, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=1, lty=1)
    #    minor.tick(nx=5, ny=5, tick.ratio=0.3)
    #    lines(predictvalues, col="red", lwd=2)
    #    lines(x,y, type="l")
  }
  
  colnames(Extractedsignalforward)=c("Voltage vs SHE (V)", "Current (�A)", "BaselineVoltage (V)","BaselineCurrent (�A)")
  
  return(Extractedsignalforward)
}




Extrapeakextractbackward=function(Namelist){
 
  p=0
  j=0
  u=0
  
  for(i in 1:length(Namelist)){
    Funclist[[i]] = Process(Namelist[i])
    message(Namelist[i])  
    Func1 = Funclist[[i]]
    Backward = Chopb(Func1)
    plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
    minor.tick(nx=5, ny=5, tick.ratio=0.3)
    smoothedbackward=smoothdat(Backward[,1],Backward[,2],0.5)
    StoredSmoothedbackward=smoothedbackward
    
    Cropping = readline(prompt="Press 1 to apply a crop before smoothing, 0 to skip cropping: ") 
    l=0
    if(Cropping == 1){
      for(b in 1:100) {if(l == 1) {break}
        else
          message(Backward[1,1])
        message(Backward[length(Backward[,1]),1])    
        
        Backward=StoredBackward
        Backward=Clip(Backward)
        smoothedbackward=smoothdat(Backward[,1],Backward[,2],0.5)
        
        plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
        minor.tick(nx=5, ny=5, tick.ratio=0.3)
        lines(StoredSmoothedbackward, type="l", col="forestgreen")
        lines(StoredBackward,type="l", lty=2)
        # lines(Forward,type="l",col="purple")
        lines(smoothedbackward, type="l", col="red")
        
        l <- readline(prompt="Press 1 to accept crop, 0 to go try again: ") 
        
      }
    }
    
    
    Smoothing = readline(prompt="Press 1 to apply smoothing, 0 to skip smoothing: ") 
    
    if(Smoothing == 1){
      Backward = data.frame(as.vector(smoothedbackward[[1]]),as.vector(smoothedbackward[[2]]))
      colnames(Backward)=c("Voltage vs SHE (V)", "Current (�A)")
      plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
      minor.tick(nx=5, ny=5, tick.ratio=0.3)
      
    }
    
    
    
    Backward=Backward[order(nrow(Backward):1),]
    Backward = Clip(Backward)
    smoothedbackward=smoothdat(Backward[,1],Backward[,2],0.5)
    
    plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
    minor.tick(nx=5, ny=5, tick.ratio=0.3)
    lines(smoothedbackward, type="l", col="forestgreen")
    
    
    
    
    for(n in 1:100) {if(j == 1) {break}
      else
        
     #   source(paste("Background codes","\\","fitbaselineusingbackward matrix.R",sep=""))
      
        regions= readline(prompt="how many regions do you want to take datapoints from: ") 
      pairsofxpoints=list()
      xpoints=c()
      
      for (i in 1:regions){
        Fitbaselineusingbackward=c()
        
        message(paste("Define region",i))
        for(g in 1:2){
          Fitbaselineusingbackward = c(Fitbaselineusingbackward, as.numeric(readline(prompt=paste("Enter Fitbaselineusingbackward",i, ": ", sep=""))))
          
        }
        xpointpair=Fitbaselineusingbackward
        pairsofxpoints[[i]]=xpointpair
        xpoints=c(xpoints,xpointpair)
      }
      
      xpointstoplot=c()
      ypoints=c()
      
      
      for(j in 1:length(xpoints)){
        
        differences=c()
        
        for(i in 1:length(smoothedbackward[[1]])){
          
          value=smoothedbackward[[1]][i]
          difference=abs(value-xpoints[j])
          differences=c(differences,difference)
        }
        
        for(k in 1:length(smoothedbackward[[1]])){
          
          if (differences[k] == min(differences)){
            xpointstoplot=c(xpointstoplot,as.numeric(smoothedbackward[[1]][k]))
            ypoints=c(ypoints,smoothedbackward[[2]][k])
          }
          
        }
        
        
      }
      
      fitbaselineusingbackward=data.frame(xpointstoplot,ypoints)
      
      
      plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
      minor.tick(nx=5, ny=5, tick.ratio=0.3)
      lines(smoothedbackward, type="l")
      points(fitbaselineusingbackward, col="red", lwd=3)
      message("got to here2")
      
      Baseline = SimpleClip(Backward,pairsofxpoints[[1]][1],pairsofxpoints[[1]][2])
      
      for(i in 2:regions){   
        Baseline = rbind(Baseline,SimpleClip(Backward,pairsofxpoints[[i]][1],pairsofxpoints[[i]][2]))
      }  
      #      Baseline=combineduplicate(Baseline)
      
      Voltagevalues= as.vector(as.matrix(Backward[,1])) 
      Voltage=Baseline[,1]
      Current = Baseline[,2]
      
      Baselinestored=Baseline
      
      Polyorder <- readline(prompt="Enter Polyorder: ")
      Polyorder = as.numeric(Polyorder)
      
      poly=lm(Current ~ poly(Voltage, Polyorder, raw=TRUE))
      
      Baselineprediction=predict(poly, list(Voltage=Voltagevalues))
      Baselinetoplot2 = data.frame(Voltagevalues,Baselineprediction)
      colnames(Baselinetoplot2)=c("BaselineVoltage (V)","BaselineCurrent (�A)")
      
      plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
      minor.tick(nx=5, ny=5, tick.ratio=0.3)
      lines(smoothedbackward, type="l")
      points(fitbaselineusingbackward, col="red", lwd=3)
      #  lines(Baseline, col="blue")
      lines(Baselinetoplot2, col="red")
      
      j <- readline(prompt="Press 1 to continue, 0 to go back: ") 
    }
    
    Backward=SimpleClip(Backward, max(fitbaselineusingbackward[,1]),min(fitbaselineusingbackward[,1]))
    Baselinetoplot2=SimpleClip(Baselinetoplot2, max(fitbaselineusingbackward[,1]),min(fitbaselineusingbackward[,1]))
    Voltagevalues= as.vector(as.matrix(Backward[,1])) 
    
    
    Extractedsignalcurrent=as.vector(as.matrix(Backward[,2]-Baselinetoplot2[,2]))
    Extractedsignalbackward=data.frame(Voltagevalues,Extractedsignalcurrent, Baselinetoplot2[,1],Baselinetoplot2[,2])
    Extractedsignalbackward=Extractedsignalbackward[order(Extractedsignalbackward[,1]),]
    
    x=as.vector(Extractedsignalbackward[,1])
    y=as.vector(Extractedsignalbackward[,2])
    smoothingSpline = smooth.spline(x, y, spar=0.1)
    predictvalues=predict(smoothingSpline, newdata=data.frame(x=x.new))
    
#    plot(x,y, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=1, lty=1)
#    minor.tick(nx=5, ny=5, tick.ratio=0.3)
#    lines(predictvalues, col="red", lwd=2)
#    lines(x,y, type="l")
  }
  
  colnames(Extractedsignalbackward)=c("Voltage vs SHE (V)", "Current (�A)", "BaselineVoltage (V)","BaselineCurrent (�A)")
  
  return(Extractedsignalbackward)
}





findhalfheightback=function(data){
  peak=min(data[,2], na.rm=TRUE)
  
  halfheight=peak/2
  halfheights=c()
  for(i in 1:length(data[,1])){
    
    if (round(data[i,2], digits = 1) == round(halfheight, digits = 1)){ 
      halfheights=c(halfheights,data[i,1])
    }
    
  }
  
  widthathalfheight=abs(max(halfheights)-min(halfheights))
  
  return(widthathalfheight)}


findhalfheightforward=function(data){
  peak=max(data[,2], na.rm=TRUE)
  
  halfheight=peak/2
  halfheights=c()
  for(i in 1:length(data[,1])){
    
    if (round(data[i,2], digits = 1) == round(halfheight, digits = 1)){ 
      halfheights=c(halfheights,data[i,1])
    }
    
  }
  
  widthathalfheight=abs(max(halfheights)-min(halfheights))
  
  return(widthathalfheight)}

Peakanodic=function(data){
  peakanoidic=max(data[,2], na.rm=TRUE)
  for(i in 1:length(data[,1])){
    if (data[i,2] == peakanoidic){
      centre=data[i,1]}
    
  }
  return(centre)
}

Peakcathoic=function(data){
  peakcathoic=min(data[,2], na.rm=TRUE)
  for(i in 1:length(data[,1])){
    if (data[i,2] == peakcathoic){
      centre=data[i,1]}
    
  }
  return(centre)
}


Chopf = function(xy){
  a = length(xy[,1])
  b = length(xy[,1])/2
  
  forward = xy[-c(b:a),]
  return(forward)
}

Chopb = function(xy){
  a = length(xy[,1])
  b = length(xy[,1])/2
  
  back = xy[-c(1:b),]
  return(back)
}

Clip = function(xy){
  z=0
  plot(xy, type="l")
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  
  
  for(n in 1:100) {if(z == 1) {break}
    else
      
      Marker1forward <- as.numeric(readline(prompt="Enter upper potential marker: "))
    Marker2forward <- as.numeric(readline(prompt="Enter lower potential marker: "))
    
    
    xpoints=c(Marker2forward,Marker1forward)
    xpointstoplot=c()
    ypoints=c()
    
    
    for(j in 1:length(xpoints)){
      
      differences=c()
      
      for(i in 1:length(xy[,1])){
        
        value=xy[i,1]
        difference=abs(value-xpoints[j])
        differences=c(differences,difference)
      }
      
      for(k in 1:length(xy[,1])){
        
        if (differences[k] == min(differences)){
          xpointstoplot=c(xpointstoplot,as.numeric(xy[k,1]))
          ypoints=c(ypoints,as.numeric(xy[k,2]))
        }
        
      }
      
      
    }
    
    markers=data.frame(xpointstoplot,ypoints)
    
    plot(xy, type="l")
    minor.tick(nx=5, ny=5, tick.ratio=0.3)
    points(markers, col="red", lwd=3)
    #    lines(smoothdat(xy[,1],xy[,2],0.5), col="green")
    
    z = as.numeric(readline(prompt="Enter 1 if you wish to proceed, 0 to try again : "))
  }
    
    
    
    
  xpoints= c()
  ypoints= c()
  
  
  for(i in 1:length(xy[,1])){
    
    if(xy[i,1] >= Marker2forward && xy[i,1] <= Marker1forward){
      xpoints= c(xpoints,xy[i,1])
      ypoints= c(ypoints,xy[i,2])
    }
  }   
  
  xy=data.frame(xpoints,ypoints)
  
  return(xy)
  
}

SimpleClip=function(xy,Fitbaselineusing1,Fitbaselineusing2){

  for(i in 1:length(xy[,1])){
    
    if(xy[i,1] >= Fitbaselineusing2 && xy[i,1] <= Fitbaselineusing1){
      xpoints= c(xpoints,xy[i,1])
      ypoints= c(ypoints,xy[i,2])
    }
  }   
  
  xy=data.frame(xpoints,ypoints)
  
  return(xy)
  
}


Process = function(Namelist){
  
  t <- paste(Namelist)
  
  x=read.table(t, skip=1, sep= "", row.names = NULL)
  x[,1] = x[,4]
  x[,1]=x[,1]-Referencepot
  x = x[,-4]
  x = x[,-2]
  x[,2] = x[,2]*1000000
  colnames(x) <- c("Voltage (V)", " Current (�A)")
  x=na.omit(x)
  return (x)
  
}

Clip2 = function(xy,Fitbaselineusing1,Fitbaselineusing2){
  
  xpoints=c()
  ypoints=c()
  for(i in 1:length(xy[,1])){
    
    if (xy[i,1]>=Fitbaselineusing1 || Fitbaselineusing2 >= xy[i,1] ){
      
      xpoints= c(xpoints,xy[i,1])
      ypoints= c(ypoints,xy[i,2])
    }
  }   
  
  xy=data.frame(xpoints,ypoints)
  
  return(xy)
  
}

#Clip2 = function(xy,Fitbaselineusing1,Fitbaselineusing2){
  
#  y=length(xy[,1])
#  dist=c()
  
#  for(i in 1:y-1){
#    x = abs(xy[i+1,1]-xy[i,1])
#    dist=c(dist,x)}
  
#  x=mean(dist)
#  z=xy[y,1]
#  q=xy[1,1]
#  g = xy[y,1]-Fitbaselineusing1
#  datapointstokeep1=round(g/x)
#  Rowstokeep1 = c(y + 1 - 1:datapointstokeep1)
  
#  f = Fitbaselineusing2-xy[1,1]
#  datapointstokeep2=round(f/x)
#  Rowstokeep2 = c(1:datapointstokeep2)
#  xy = xy[c(Rowstokeep2,Rowstokeep1),]
  
#  return(xy)
#}

Process = function(Namelist){
  
  t <- paste(Namelist)
  
  x=read.table(t, skip=1, sep= "", row.names = NULL)
  x[,1] = x[,4]
  x[,1]=x[,1]-Referencepot
  x = x[,-4]
  x = x[,-2]
  x[,2] = x[,2]*1000000
  colnames(x) <- c("Voltage (V)", " Current (�A)")
  x=na.omit(x)
  return (x)
  
}

Findcoverage=function(Isolated_peak,electrodearea,scanrate,n){
  
  Isolated_peak[ "New1" ] <- NA
  Isolated_peak[ "New2" ] <- NA
  Isolated_peak[ "New3" ] <- NA
  
  colnames(Isolated_peak) <- c("Voltage (V)", " Current (�A)", "E2-E1", "Current2+Current1", "Trapesium")
  
  for (i in 1:length(Isolated_peak[,1])){
    Isolated_peak[i+1,3]=Isolated_peak[i+1,1] - Isolated_peak[i,1]
    Isolated_peak[i+1,4]=Isolated_peak[i+1,2] + Isolated_peak[i,2]
  }
  
  Isolated_peak=Isolated_peak[-c(1),]
  
  for (i in 1:length(Isolated_peak[,1])){
    Isolated_peak[i,5]=0.5*Isolated_peak[i,3]*Isolated_peak[i,4]
  }
  
  Integral_of_peak=sum(Isolated_peak$Trapesium,na.rm=TRUE)
  
  x=Integral_of_peak/1000000
  y=scanrate/1000
  z=x/y
  g=z*1000000000000/96485.3329
  j=g/n
  A=j/electrodearea
  
  return(A)
}

smoothdat=function(x,y,z){
  smoothingSplinexy=smooth.spline(x, y, spar=z)
  predictvaluesxy=predict(smoothingSplinexy,newdata=data.frame(x=x.new))
  
  return(predictvaluesxy)
}

differential=function(x,y){
  
  dybydx=c()
  xcoords=c()
  
  for (i in 1:length(x)-1){
    dx=x[i+1]-x[i]
    dy=y[i+1]-y[i]
    
    dybydx=c(dybydx,dy/dx)
    xcoords=c(xcoords,x[i])
    
  }
  return(data.frame(xcoords,dybydx))
}



findpointsthatequalzero=function(x,y,digits){
  points0y=c()
  points0x=c()
  
  for(i in 1:length(y)){
    pointtoanalyse=round(y[i], digits = digits)
    if(pointtoanalyse == 0){
      points0y=c(points0y,y[i])
      points0x=c(points0x,x[i])
    }
    
  }
  return(data.frame(points0x,points0y))
  
}

findpointsthatnearlyequalzero=function(x,y,tolerance){
  points0y=c()
  points0x=c()
  
  for(i in 1:length(y)){
    pointtoanalyse=y[i]
    if((((pointtoanalyse)^2)^0.5) <= tolerance){
      points0y=c(points0y,y[i])
      points0x=c(points0x,x[i])
    }
    
  }
  return(data.frame(points0x,points0y))
  
}

maximumbounds=function(x){
  rangereq=c(((max(range(x)))^2)^0.5,((min(range(x)))^2)^0.5)
  
  return(max(rangereq))
}

smoothadataset=function(xy,smoothdegree){
  xyF=Chopf(xy)
  xyF=smoothdat(xyF[,1],xyF[,2],smoothdegree)
  xyF = data.frame(as.vector(xyF[[1]]),as.vector(xyF[[2]]))
  colnames(xyF)=c("Voltage vs SHE (V)", "Current (�A)")
  xyF= xyF[order(xyF[,1]),]
  
  xyB = Chopb(xy)
  xyB=smoothdat(xyB[,1],xyB[,2],smoothdegree)
  xyB = data.frame(as.vector(xyB[[1]]),as.vector(xyB[[2]]))
  colnames(xyB)=c("Voltage vs SHE (V)", "Current (�A)")
  xyB= xyB[order(-xyB[,1]),]
  
  smoothedplot=rbind(xyF,xyB)
  xy=smoothedplot
  
  return(xy)
}

library(Hmisc)
