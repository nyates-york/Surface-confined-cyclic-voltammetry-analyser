RandommatrixCath=matrix(-1:1, nrow=length(ParameterlistCath), ncol=Numsig)


ParameterinputstoredCath=ParameterinputCath


for (i in 1:length(ParameterinputCath[,1])){
  for (j in 1:length(ParameterinputCath[1,])){
    ParameterinputCath[i,j]=ParameterinputCath[i,j]+(ParameterinputCath[i,j]*RandommatrixCath[i,j]/300)
    ParameterinputCath[1,j]=ParameterinputstoredCath[1,j]  # hash out this line if number of electrons in a couple isn't set
    if(ParameterinputCath[3,j] < 0.7){
      ParameterinputCath[3,j]=ParameterinputstoredCath[3,j]  # hash out this loop to remove restrictions on apparent number of electrons
    }
    }
}




PredictedpeakCath=list()

for (i in 1:length(ParameterinputCath[1,])){
  Cathicexpterm= exp(ParameterinputCath[3,i]*Faraday*(Extractedsignalforward[,1]-ParameterinputCath[2,i])/(Gas*Temperature))
  collectionofconstants=ParameterinputCath[3,i]*ParameterinputCath[1,i]*Faraday*Faraday*Scanrate*ElectrodeArea*ParameterinputCath[4,i]/(Gas*Temperature)
  PredictedCath=-1000000*collectionofconstants*Cathicexpterm/(((1+Cathicexpterm)^2))
  PredictedpeakCath[[i]]=PredictedCathI
}

ReconstructedCathodic=PredictedpeakCath[[1]]

for (i in 2:length(ParameterinputCath[1,])){
  ReconstructedCathodic=ReconstructedCathodic+PredictedpeakCath[[i]]
}

dataframeextractx2=Extractedpeaksbackwards[[1]]
dataframeextracty2=Extractedpeaksbackwards[[2]]

R2=(dataframeextracty2-ReconstructedCathodic)^2
SumR2=sum(R2)


