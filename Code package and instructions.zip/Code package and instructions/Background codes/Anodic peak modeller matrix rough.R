RandommatrixAnod=matrix(-1:1, nrow=length(ParameterlistAnod), ncol=Numsig)


ParameterinputstoredAnod=ParameterinputAnod


for (i in 1:length(ParameterinputAnod[,1])){
  for (j in 1:length(ParameterinputAnod[1,])){
    ParameterinputAnod[i,j]=ParameterinputAnod[i,j]+(ParameterinputAnod[i,j]*RandommatrixAnod[i,j]/10)
    ParameterinputAnod[1,j]=ParameterinputstoredAnod[1,j]  # hash out this line if number of electrons in a couple isn't set
    if(ParameterinputAnod[3,j] < 0.7){
    ParameterinputAnod[3,j]=ParameterinputstoredAnod[3,j]  # hash out this loop to remove restrictions on apparent number of electrons
    }
  }
}



#Variablesvector=c(Anodicpeakpotfirst,Anodicpeakpotsecond,AnodicAppelectronsfirst,AnodicElectrodecoveragefirst,AnodicAppelectronssecond,AnodicElectrodecoveragesecond)

PredictedpeakAnod=list()

for (i in 1:length(ParameterinputAnod[1,])){
  Anodicexpterm= exp(ParameterinputAnod[3,i]*Faraday*(Extractedsignalforward[,1]-ParameterinputAnod[2,i])/(Gas*Temperature))
  collectionofconstants=ParameterinputAnod[3,i]*ParameterinputAnod[1,i]*Faraday*Faraday*Scanrate*ElectrodeArea*ParameterinputAnod[4,i]/(Gas*Temperature)
  PredictedAnodicI=1000000*collectionofconstants*Anodicexpterm/(((1+Anodicexpterm)^2))
  PredictedpeakAnod[[i]]=PredictedAnodicI
  }
  
Reconstructedanodic=PredictedpeakAnod[[1]]

for (i in 2:length(ParameterinputAnod[1,])){
  Reconstructedanodic=Reconstructedanodic+PredictedpeakAnod[[i]]
}


dataframeextractx=Extractedpeaksforward[[1]]
dataframeextracty=Extractedpeaksforward[[2]]

R2=(dataframeextracty-Reconstructedanodic)^2
SumR2=sum(R2)


