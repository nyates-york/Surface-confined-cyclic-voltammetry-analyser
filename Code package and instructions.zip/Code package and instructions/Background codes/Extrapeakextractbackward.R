p=0
j=0
u=0
l=0


for(i in 1:length(Namelist)){
  Funclist[[i]] = Process(Namelist[i])
  message(Namelist[i])  
  Func1 = Funclist[[i]]    
  
  Backward = Chopb(Func1)
  Backward=Backward[order(nrow(Backward):1),]
  smoothedbackward=smoothdat(Backward[,1],Backward[,2],0.5)
  
  plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  lines(smoothedbackward, type="l", col="forestgreen")
  StoredBackward=Backward
  StoredSmoothedbackward=smoothedbackward
  
  Cropping = readline(prompt="Press 1 to apply a crop before smoothing, 0 to skip cropping: ") 
  
  if(Cropping == 1){
    for(b in 1:100) {if(l == 1) {break}
      else
        message(Backward[1,1])
      message(Backward[length(Backward[,1]),1])    
      
      Backward=StoredBackward
      Backward=Clip(Backward)
      smoothedbackward=smoothdat(Backward[,1],Backward[,2],0.5)
      
      plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
      minor.tick(nx=5, ny=5, tick.ratio=0.3)
      lines(StoredSmoothedbackward, type="l", col="forestgreen")
      lines(StoredBackward,type="l", lty=2)
      # lines(Forward,type="l",col="purple")
      lines(smoothedbackward, type="l", col="red")
      
      l <- readline(prompt="Press 1 to accept crop, 0 to go try again: ") 
      
    }
  }
  
  
  Smoothing = readline(prompt="Press 1 to apply smoothing, 0 to skip smoothing: ") 
  
  if(Smoothing == 1){
    Backward = data.frame(as.vector(smoothedbackward[[1]]),as.vector(smoothedbackward[[2]]))
    colnames(Backward)=c("Voltage vs SHE (V)", "Current (�A)")
    plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
    minor.tick(nx=5, ny=5, tick.ratio=0.3)
    
  }
  
  
  
  Backward = Clip(Backward)
  smoothedbackward=smoothdat(Backward[,1],Backward[,2],0.5)
  
  plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  lines(smoothedbackward, type="l", col="forestgreen")
  
  
  
  
  
  for(n in 1:100) {if(j == 1) {break}
    else
      
      source(paste("Background codes","\\","fitbaselineusingbackward matrix multiple.R",sep=""))
    
    plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)")
    minor.tick(nx=5, ny=5, tick.ratio=0.3)
    lines(smoothedbackward, type="l", col="forestgreen")
    points(fitbaselineusingbackward, col="red", lwd=3)
    
    Baseline = SimpleClip(Backward,pairsofxpoints[[1]][1],pairsofxpoints[[1]][2])
    
    for(i in 2:regions){   
      Baseline = rbind(Baseline,SimpleClip(Backward,pairsofxpoints[[i]][1],pairsofxpoints[[i]][2]))
    }
    
    Baseline=Baseline[order(Baseline[,1]),]
    # Baseline=combineduplicate(Baseline)
    Voltagevalues= as.vector(as.matrix(Backward[,1])) 
    Voltage=Baseline[,1]
    Current = Baseline[,2]
    
    Baselinestored=Baseline
    
    Polyorder <- readline(prompt="Enter Polyorder: ")
    Polyorder = as.numeric(Polyorder)
    
    poly=lm(Current ~ poly(Voltage, Polyorder, raw=TRUE))
    
    Baselineprediction=predict(poly, list(Voltage=Voltagevalues))
    Baselinetoplot2 = data.frame(Voltagevalues,Baselineprediction)
    colnames(Baselinetoplot2)=c("Voltage vs SHE (V)", "Current (�A)")
    
    
    plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)")
    minor.tick(nx=5, ny=5, tick.ratio=0.3)
    lines(smoothedbackward, type="l", col="forestgreen")
    points(fitbaselineusingbackward, col="red", lwd=3)
    #  lines(Baseline, col="blue")
    lines(Baselinetoplot2, col="red")
    
    
    
    j <- readline(prompt="Press 1 to continue, 0 to go back: ") 
  }
  
  Backward=SimpleClip(Backward, max(fitbaselineusingbackward[,1]),min(fitbaselineusingbackward[,1]))
  Baselinetoplot2=SimpleClip(Baselinetoplot2, max(fitbaselineusingbackward[,1]),min(fitbaselineusingbackward[,1]))
  Voltagevalues= as.vector(as.matrix(Backward[,1])) 
  colnames(Baselinetoplot2)=c("Voltage vs SHE (V)", "Current (�A)")
  
  Extractedsignalcurrent=as.vector(as.matrix(Backward[,2]-Baselinetoplot2[,2]))
  Extractedsignalbackward=data.frame(Voltagevalues,Extractedsignalcurrent)
  Extractedsignalbackward=Extractedsignalbackward[order(Extractedsignalbackward[,1]),]
  
  colnames(Extractedsignalbackward)=c("Voltage vs SHE (V)", "Current (�A)")
  
  x=as.vector(Extractedsignalbackward[,1])
  y=as.vector(Extractedsignalbackward[,2])
  
  smoothingSpline = smooth.spline(x, y, spar=0.1)
  predictvalues=predict(smoothingSpline, newdata=data.frame(x=x.new))
  
  plot(x,y, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=1, lty=1)
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  lines(predictvalues, col="red", lwd=2)
  lines(x,y, type="l")
}