Anodicpeakpot=c()
for (i in 1:length(ParameterinputAnod[1,])){
  Anodicpeakpot = c(Anodicpeakpot, as.numeric(readline(prompt=paste("Enter voltage of peak ",i, "(in volts): ", sep=""))))
  
}


xpoints=rev(Anodicpeakpot)
xpointstoplot=c()
ypoints=c()



for(j in 1:length(xpoints)){
  
  differences=c()
  
  for(i in 1:length(predictvalues[[1]])){
    
    value=predictvalues[[1]][i]
    difference=abs(value-xpoints[j])
    differences=c(differences,difference)
  }
  
  for(k in 1:length(predictvalues[[1]])){
    
    if (differences[k] == min(differences)){
      xpointstoplot=c(xpointstoplot,as.numeric(predictvalues[[1]][k]))
      ypoints=c(ypoints,predictvalues[[2]][k])
    }
    
  }
  
  
}


plotpointsforward=data.frame(xpointstoplot,ypoints)

