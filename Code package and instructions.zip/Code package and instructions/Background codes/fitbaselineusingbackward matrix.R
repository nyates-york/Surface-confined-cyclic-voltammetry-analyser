Fitbaselineusingbackward=c()
for (i in 1:2){
  Fitbaselineusingbackward = c(Fitbaselineusingbackward, as.numeric(readline(prompt=paste("Enter Fitbaselineusingbackward",i, ": ", sep=""))))
  
}



xpoints=rev(Fitbaselineusingbackward)
xpointstoplot=c()
ypoints=c()



for(i in 1:length(smoothedbackward[[1]])){
  
  value=round(smoothedbackward[[1]][i],digits=2)
  
  for(j in 1:length(xpoints)){
    
    if (value == round(xpoints[j], digits=2)){
      xpointstoplot=c(xpointstoplot,as.numeric(smoothedbackward[[1]][i]))
      ypoints=c(ypoints,smoothedbackward[[2]][i])
    }
  }
}
fitbaselineusingbackward=data.frame(xpointstoplot,ypoints)

