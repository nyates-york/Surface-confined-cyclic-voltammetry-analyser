Fitbaselineusing1forward <- as.numeric(readline(prompt="Enter Fitbaselineusing1forward: "))
Fitbaselineusing2forward <- as.numeric(readline(prompt="Enter Fitbaselineusing2forward: "))


xpoints=c(Fitbaselineusing2forward,Fitbaselineusing1forward)
xpointstoplot=c()
ypoints=c()



for(i in 1:length(smoothedforward[[1]])){
  
  value=round(smoothedforward[[1]][i],digits=2)
  
  for(j in 1:length(xpoints)){
    
    if (value == round(xpoints[j], digits=2)){
      xpointstoplot=c(xpointstoplot,as.numeric(smoothedforward[[1]][i]))
      ypoints=c(ypoints,smoothedforward[[2]][i])
    }
  }
}
fitbaselineusingforward=data.frame(xpointstoplot,ypoints)

