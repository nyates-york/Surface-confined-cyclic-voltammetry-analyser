smoothmainplot=as.numeric(readline(prompt = "Press 1 if you want to smooth the main plot, 0 to skip this: "))

if (smoothmainplot == 1) {

for(i in 1:length(Namelist)){
  Funclist[[i]] = Process(Namelist[i])
  message(Namelist[i])  
  Func1 = Funclist[[i]]
  Forward=Chopf(Func1)
  
  smoothedforward=smoothdat(Forward[,1],Forward[,2],0.5)
  smoothedforward = data.frame(as.vector(smoothedforward[[1]]),as.vector(smoothedforward[[2]]))
  colnames(smoothedforward)=c("Voltage vs SHE (V)", "Current (�A)")
smoothedforward= smoothedforward[order(smoothedforward[,1]),]

#GCblank1=read.table(GCblanknames[1],skip=1, sep= "", row.names = NULL)
#GCblank1[,1] = GCblank1[,4]
#GCblank1[,1]=GCblank1[,1]-Referencepot
#GCblank1 = GCblank1[,-4]
#GCblank1 = GCblank1[,-2]
#GCblank1[,2] = GCblank1[,2]*1000000
#colnames(GCblank1) <- c("Voltage (V)", " Current (�A)")
#GCblank1=na.omit(GCblank1)

GCblank1=Process(GCblank)
GCblankF=Chopf(GCblank1)
smoothedGCblankF=smoothdat(GCblankF[,1],GCblankF[,2],0.5)
smoothedGCblankF = data.frame(as.vector(smoothedGCblankF[[1]]),as.vector(smoothedGCblankF[[2]]))
colnames(smoothedGCblankF)=c("Voltage vs SHE (V)", "Current (�A)")
smoothedGCblankF= smoothedGCblankF[order(smoothedGCblankF[,1]),]

Nanoblank1=Process(Nanoblank)
NanoblankF=Chopf(Nanoblank1)
smoothedNanoblankF=smoothdat(NanoblankF[,1],NanoblankF[,2],0.5)
smoothedNanoblankF = data.frame(as.vector(smoothedNanoblankF[[1]]),as.vector(smoothedNanoblankF[[2]]))
colnames(smoothedNanoblankF)=c("Voltage vs SHE (V)", "Current (�A)")
smoothedNanoblankF= smoothedNanoblankF[order(smoothedNanoblankF[,1]),]
}


for(i in 1:length(Namelist)){
  Funclist[[i]] = Process(Namelist[i])
  message(Namelist[i])  
  Func1 = Funclist[[i]]
  Backward = Chopb(Func1)
  
  plot(Backward, xlab="Voltage vs SHE (V)", ylab="Current (�A)", type="l")
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  
  smoothedbackward=smoothdat(Backward[,1],Backward[,2],0.5)
  smoothedbackward = data.frame(as.vector(smoothedbackward[[1]]),as.vector(smoothedbackward[[2]]))
  colnames(smoothedbackward)=c("Voltage vs SHE (V)", "Current (�A)")
  smoothedbackward= smoothedbackward[order(-smoothedbackward[,1]),]
  
  GCblank1=Process(GCblank)
  GCblankB=Chopb(GCblank1)
  smoothedGCblankB=smoothdat(GCblankB[,1],GCblankB[,2],0.5)
  smoothedGCblankB = data.frame(as.vector(smoothedGCblankB[[1]]),as.vector(smoothedGCblankB[[2]]))
  colnames(smoothedGCblankB)=c("Voltage vs SHE (V)", "Current (�A)")
  smoothedGCblankB= smoothedGCblankB[order(smoothedGCblankB[,1]),]
  
  Nanoblank1=Process(Nanoblank)
  NanoblankB=Chopb(Nanoblank1)
  smoothedNanoblankB=smoothdat(NanoblankB[,1],NanoblankB[,2],0.5)
  smoothedNanoblankB = data.frame(as.vector(smoothedNanoblankB[[1]]),as.vector(smoothedNanoblankB[[2]]))
  colnames(smoothedNanoblankB)=c("Voltage vs SHE (V)", "Current (�A)")
  smoothedNanoblankB= smoothedNanoblankB[order(smoothedNanoblankB[,1]),]

}
#Namelist="LPMO 63_4"
smoothedplot=rbind(smoothedforward,smoothedbackward)
Func1=smoothedplot

smoothedGCblankplot=rbind(smoothedGCblankB,smoothedGCblankF[order(-smoothedGCblankF[,1]),])
GCblankplot=smoothedGCblankplot

smoothedNanoblankplot=rbind(smoothedNanoblankB,smoothedNanoblankF[order(-smoothedNanoblankF[,1]),])
Nanoblankplot=smoothedNanoblankplot


}
  
  if (smoothmainplot != 1) {
for(i in 1:length(Namelist)){
  Funclist[[i]] = Process(Namelist[i])
  message(Namelist[i])  
  Func1 = Funclist[[i]]}
  
    GCblankplot=Process(GCblank)
    Nanoblankplot=Process(Nanoblank)
    
}

end=Func1[length(Func1[,1]),]
start=Func1[1,]

Fullcircx=c(start[,1],start[,1],end[,1])
Fullcircy=c(end[,2],start[,2],start[,2])

Extractedpeaksforwarddfx=unlist(Extractedpeaksforward[[1]][1])
Extractedpeaksforwarddfy=unlist(Extractedpeaksforward[[1]][2])

Extractedpeaksbackwardsdfx=unlist(Extractedpeaksbackwards[[1]][1])
Extractedpeaksbackwardsdfy=unlist(Extractedpeaksbackwards[[1]][2])

h=0

scalefactor=1

graphcol=c("forestgreen","Orange","cornflowerblue","deeppink","coral1")

legendentry=c()
lwdvec=c()
ltyvec=c()
colvec=c()

for (i in 1:length(NumsigA)){
  legendpart=paste("Simulated signal ",NumsigA[i])
  legendentry=c(legendentry,legendpart)
  ltyvec=c(ltyvec,1)
  lwdvec=c(lwdvec,2)
  colvec=c(colvec,graphcol[i])
  
}

plot(Func1, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2)
minor.tick(nx=5, ny=5, tick.ratio=0.3)
lines(Fullcircx,Fullcircy, lwd=2)

lines(GCblankplot, lty=4, col="darkgray", lwd=2)
lines(Nanoblankplot, lty=2, col="darkgray", lwd=2)
lines(Func1, lwd=2)



lines(Baselinetoplot1, col="red")
lines(Baselinetoplot2, col="red")

#lines(Extractedpeaksforwarddfx,Extractedpeaksforwarddfy*scalefactor, col="cyan3",lwd=2)
#lines(Extractedpeaksbackwardsdfx,Extractedpeaksbackwardsdfy*scalefactor, col="cyan3",lwd=2)
lines(Extractedpeaksforward[[1]],Reconstructedanodic*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
for(g in 1:length(namevec)){
  
  o=length(namevec)-g+1
  lines(Extractedpeaksforward[[1]],PredictedAnodicIlist[[o]]*scalefactor, col=graphcol[o],lwd=2)
  lines(Extractedpeaksbackwards[[1]],PredictedCathIlist[[o]]*scalefactor, col=graphcol[o],lwd=2)
  
}
lines(Extractedpeaksforward[[1]],Reconstructedanodic*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
lines(Extractedpeaksbackwards[[1]],ReconstructedCath*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
lines(Extractedpeaksforward[[1]],Extractedpeaksforward[[2]]*scalefactor, col="black", lwd=2, lty=2)
lines(Extractedpeaksbackwards[[1]],Extractedpeaksbackwards[[2]]*scalefactor, col="black", lwd=2, lty=2)

legend("topleft", legend=c("Nanotubes+LPMO","Extracted signal", "Baseline","Nanotubes","GC",legendentry, "Reconstructed signal"),
       col=c("Black","Black","Red","darkgray","darkgray",colvec, "purple"), lwd=c(2,2,1,2,2,lwdvec), lty=c(1,2,1,2,4,ltyvec), cex=0.9, bty="n")




for(i in 1:100){
  if(h==1){break}
  else

scalefactor=as.numeric(readline(prompt = "Enter scale factor for extracted peaks?: "))


  plot(Func1, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2)
  minor.tick(nx=5, ny=5, tick.ratio=0.3)
  lines(Fullcircx,Fullcircy, lwd=2)
  
  lines(GCblankplot, lty=4, col="darkgray", lwd=2)
  lines(Nanoblankplot, lty=2, col="darkgray", lwd=2)
  lines(Func1, lwd=2)
  
  
  
  lines(Baselinetoplot1, col="red")
  lines(Baselinetoplot2, col="red")
  
  #lines(Extractedpeaksforwarddfx,Extractedpeaksforwarddfy*scalefactor, col="cyan3",lwd=2)
  #lines(Extractedpeaksbackwardsdfx,Extractedpeaksbackwardsdfy*scalefactor, col="cyan3",lwd=2)
  lines(Extractedpeaksforward[[1]],Reconstructedanodic*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
  for(g in 1:length(namevec)){
    o=length(namevec)-g+1
    lines(Extractedpeaksforward[[1]],PredictedAnodicIlist[[o]]*scalefactor, col=graphcol[o],lwd=2)
    lines(Extractedpeaksbackwards[[1]],PredictedCathIlist[[o]]*scalefactor, col=graphcol[o],lwd=2)
    
  }
  lines(Extractedpeaksforward[[1]],Reconstructedanodic*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
  lines(Extractedpeaksbackwards[[1]],ReconstructedCath*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
  lines(Extractedpeaksforward[[1]],Extractedpeaksforward[[2]]*scalefactor, col="black", lwd=2, lty=2)
  lines(Extractedpeaksbackwards[[1]],Extractedpeaksbackwards[[2]]*scalefactor, col="black", lwd=2, lty=2)
  
  legend("topleft", legend=c("Nanotubes+LPMO","Extracted signal", "Baseline","Nanotubes","GC",legendentry, "Reconstructed signal"),
         col=c("Black","Black","Red","darkgray","darkgray",colvec, "purple"), lwd=c(2,2,1,2,2,lwdvec), lty=c(1,2,1,2,4,ltyvec), cex=0.9, bty="n")
  
  
  
h=as.numeric(readline(prompt = "Press 1 to accept the graph, 0 to re-apply a scale factor: "))
}

pdf(paste(Destination,Designation,".pdf", step=""),width = 5, height = 5)
plot(Func1, type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2)
minor.tick(nx=5, ny=5, tick.ratio=0.3)
lines(Fullcircx,Fullcircy, lwd=2)

lines(GCblankplot, lty=4, col="darkgray", lwd=2)
lines(Nanoblankplot, lty=2, col="darkgray", lwd=2)
lines(Func1, lwd=2)



lines(Baselinetoplot1, col="red")
lines(Baselinetoplot2, col="red")

#lines(Extractedpeaksforwarddfx,Extractedpeaksforwarddfy*scalefactor, col="cyan3",lwd=2)
#lines(Extractedpeaksbackwardsdfx,Extractedpeaksbackwardsdfy*scalefactor, col="cyan3",lwd=2)
lines(Extractedpeaksforward[[1]],Reconstructedanodic*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
for(g in 1:length(namevec)){
  o=length(namevec)-g+1
  lines(Extractedpeaksforward[[1]],PredictedAnodicIlist[[o]]*scalefactor, col=graphcol[o],lwd=2)
  lines(Extractedpeaksbackwards[[1]],PredictedCathIlist[[o]]*scalefactor, col=graphcol[o],lwd=2)
  
}
lines(Extractedpeaksforward[[1]],Reconstructedanodic*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
lines(Extractedpeaksbackwards[[1]],ReconstructedCath*scalefactor,type="l", xlab="Voltage vs SHE (V)", ylab="Current (�A)", lwd=2, lty=1, col="purple")
lines(Extractedpeaksforward[[1]],Extractedpeaksforward[[2]]*scalefactor, col="black", lwd=2, lty=2)
lines(Extractedpeaksbackwards[[1]],Extractedpeaksbackwards[[2]]*scalefactor, col="black", lwd=2, lty=2)

legend("topleft", legend=c("Nanotubes+LPMO","Extracted signal", "Baseline","Nanotubes","GC",legendentry, "Reconstructed signal"),
       col=c("Black","Black","Red","darkgray","darkgray",colvec, "purple"), lwd=c(2,2,1,2,2,lwdvec), lty=c(1,2,1,2,4,ltyvec), cex=0.9, bty="n")


dev.off()