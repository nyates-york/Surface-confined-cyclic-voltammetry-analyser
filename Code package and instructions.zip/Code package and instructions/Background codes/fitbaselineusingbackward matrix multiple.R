regions= readline(prompt="how many regions do you want to take datapoints from: ") 
pairsofxpoints=list()
xpoints=c()

for (i in 1:regions){
  Fitbaselineusingbackward=c()
  
  message(paste("Define region",i))
  for(g in 1:2){
    Fitbaselineusingbackward = c(Fitbaselineusingbackward, as.numeric(readline(prompt=paste("Enter Fitbaselineusingbackward",i, ": ", sep=""))))
    
  }
  xpointpair=Fitbaselineusingbackward
  pairsofxpoints[[i]]=xpointpair
  xpoints=c(xpoints,xpointpair)
}

xpointstoplot=c()
ypoints=c()


for(j in 1:length(xpoints)){
  
  differences=c()
  
  for(i in 1:length(smoothedbackward[[1]])){
    
    value=smoothedbackward[[1]][i]
    difference=abs(value-xpoints[j])
    differences=c(differences,difference)
  }
  
  for(k in 1:length(smoothedbackward[[1]])){
    
    if (differences[k] == min(differences)){
      xpointstoplot=c(xpointstoplot,as.numeric(smoothedbackward[[1]][k]))
      ypoints=c(ypoints,smoothedbackward[[2]][k])
    }
    
  }
  
  
}

fitbaselineusingbackward=data.frame(xpointstoplot,ypoints)

