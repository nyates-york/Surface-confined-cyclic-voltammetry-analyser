Fitbaselineusingforward=c()
for (i in 1:2){
  Fitbaselineusingforward = c(Fitbaselineusingforward, as.numeric(readline(prompt=paste("Enter Fitbaselineusingforward",i, ": ", sep=""))))
  
}


xpoints=rev(Fitbaselineusingforward)
xpointstoplot=c()
ypoints=c()



for(i in 1:length(smoothedforward[[1]])){
  
  value=round(smoothedforward[[1]][i],digits=2)
  
  for(j in 1:length(xpoints)){
    
    if (value == round(xpoints[j], digits=2)){
      xpointstoplot=c(xpointstoplot,as.numeric(smoothedforward[[1]][i]))
      ypoints=c(ypoints,smoothedforward[[2]][i])
    }
  }
}
fitbaselineusingforward=data.frame(xpointstoplot,ypoints)

