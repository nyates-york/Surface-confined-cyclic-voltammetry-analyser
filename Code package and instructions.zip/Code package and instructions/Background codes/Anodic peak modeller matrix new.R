PredictedAnodicIlist=list()

ParameterinputstoredAnod=ParameterinputAnod

for(l in 1:length(ParameterinputAnod[1,])){
  Variablesvector=c(ParameterinputAnod[2,l],ParameterinputAnod[3,l],ParameterinputAnod[4,l])
  Randomnumbervector=sample.int(3, 3, replace = TRUE)
  Randomnumbervector=Randomnumbervector-2

  Variablesvector=Variablesvector+(Variablesvector*Randomnumbervector/300)
  
  if(Variablesvector[2] < 0.7){
    Variablesvector[2] = 0.8
  }
  
  #the above means that the CathodicAppelectrons cannot fall below 0.7
  #and it resets it to 0.8. If n=2 for the redox process this constraint
  #could be modifed so that CathodicAppelectrons couldn't fall below 1.5
  #or something else appropriate
  
  else
  
  ParameterinputAnod[2,l]=Variablesvector[1]
  ParameterinputAnod[3,l]=Variablesvector[2]
  ParameterinputAnod[4,l]=Variablesvector[3]
  
  Anodicexpterm = exp(Variablesvector[2]*Faraday*(Extractedpeaksforward[[1]]-Variablesvector[1])/(Gas*Temperature))
  collectionofconstants=Variablesvector[2]*ParameterinputAnod[1,l]*Faraday*Faraday*Scanrate*ElectrodeArea*Variablesvector[3]/(Gas*Temperature)
  PredictedAnodicI= 1000000*collectionofconstants*Anodicexpterm/(((1+Anodicexpterm)^2))
  PredictedAnodicIlist[[l]]=PredictedAnodicI
}

#plot(PredictedAnodicI)
Reconstructedanodic=PredictedAnodicIlist[[1]]

for(h in 2:length(ParameterinputAnod[1,])){
  Reconstructedanodic=Reconstructedanodic+PredictedAnodicIlist[[h]]
}
  

dataframeextractx=Extractedpeaksforward[[1]]
dataframeextracty=Extractedpeaksforward[[2]]

R2=(dataframeextracty-Reconstructedanodic)^2
SumR2=sum(R2)


