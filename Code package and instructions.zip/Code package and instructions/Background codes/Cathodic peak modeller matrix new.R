PredictedCathIlist=list()

ParameterinputstoredCath=ParameterinputCath

for(l in 1:length(ParameterinputCath[1,])){
  Variablesvector=c(ParameterinputCath[2,l],ParameterinputCath[3,l],ParameterinputCath[4,l])
  Randomnumbervector=sample.int(3, 3, replace = TRUE)
  Randomnumbervector=Randomnumbervector-2
  
  Variablesvector=Variablesvector+(Variablesvector*Randomnumbervector/300)
  
  if(Variablesvector[2] < 0.7){
    Variablesvector[2] = 0.8
  }
    #the above means that the CathodicAppelectrons cannot fall below 0.7
  #and it resets it to 0.8. If n=2 for the redox process this constraint
  #could be modifed so that CathodicAppelectrons couldn't fall below 
  #0.7*NumelectronsCathodic or something else appropriate
  #to do this could could write
  
  #if(Variablesvector[2] < 0.7*ParameterinputCath[1,l]){
  #  Variablesvector[2] = 0.8*ParameterinputCath[1,l]
  #}
  
  else
    
  ParameterinputCath[2,l]=Variablesvector[1]
  ParameterinputCath[3,l]=Variablesvector[2]
  ParameterinputCath[4,l]=Variablesvector[3]
  
  Cathexpterm = exp(Variablesvector[2]*Faraday*(Extractedpeaksbackwards[[1]]-Variablesvector[1])/(Gas*Temperature))
  collectionofconstants=Variablesvector[2]*ParameterinputCath[1,l]*Faraday*Faraday*Scanrate*ElectrodeArea*Variablesvector[3]/(Gas*Temperature)
  PredictedCathI= -1000000*collectionofconstants*Cathexpterm/(((1+Cathexpterm)^2))
  PredictedCathIlist[[l]]=PredictedCathI
}

#plot(PredictedCathI)
ReconstructedCath=PredictedCathIlist[[1]]

for(h in 2:length(ParameterinputCath[1,])){
  ReconstructedCath=ReconstructedCath+PredictedCathIlist[[h]]
}


dataframeextractx2=Extractedpeaksbackwards[[1]]
dataframeextracty2=Extractedpeaksbackwards[[2]]


R2=(dataframeextracty2-ReconstructedCath)^2
SumR2=sum(R2)



